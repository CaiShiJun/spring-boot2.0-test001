package com.example.demo.core.constant;

public class ExcelConstant {

    /**
     * 生成文件存放路径
     */
    public static final String FILE_PATH = "C:\\Users\\Administrator\\Desktop\\";

    /**
     * 表格默认名称
     */
    public static final String FILE_NAME = "TEST.xls";
}
