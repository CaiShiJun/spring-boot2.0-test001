package com.example.demo.dao.db1;

import com.example.demo.core.universal.Mapper;
import com.example.demo.model.SysRole;

public interface SysRoleMapper extends Mapper<SysRole> {
}