package com.example.demo.dao.db1;

import com.example.demo.core.universal.Mapper;
import com.example.demo.model.SysPerm;

public interface SysPermMapper extends Mapper<SysPerm> {
}