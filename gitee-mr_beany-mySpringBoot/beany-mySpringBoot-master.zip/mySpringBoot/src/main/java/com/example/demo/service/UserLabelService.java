package com.example.demo.service;

import com.example.demo.model.UserLabel;
import com.example.demo.core.universal.Service;

/**
* @Description: UserLabelService接口
* @author 张瑶
* @date 2018/04/29 19:09
*/
public interface UserLabelService extends Service<UserLabel> {

}