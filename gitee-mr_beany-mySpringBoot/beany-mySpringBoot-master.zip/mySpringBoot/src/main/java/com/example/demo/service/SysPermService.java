package com.example.demo.service;

import com.example.demo.model.SysPerm;
import com.example.demo.core.universal.Service;

/**
* @Description: SysPermService接口
* @author 张瑶
* @date 2018/05/26 00:30
*/
public interface SysPermService extends Service<SysPerm> {

}