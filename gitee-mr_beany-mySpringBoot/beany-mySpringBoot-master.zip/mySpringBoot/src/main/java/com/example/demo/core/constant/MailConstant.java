package com.example.demo.core.constant;

public class MailConstant {

    /**
     * 注册的模板名称
     */
    public static final String RETGISTEREMPLATE = "register";

    /**
     * 模板存放的路径
     */
    public static final String TEMPLATEPATH = "src/test/java/resources/template/mail";
}
