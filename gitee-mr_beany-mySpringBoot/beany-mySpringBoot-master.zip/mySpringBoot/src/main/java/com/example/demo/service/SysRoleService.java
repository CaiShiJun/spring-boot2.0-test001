package com.example.demo.service;

import com.example.demo.model.SysRole;
import com.example.demo.core.universal.Service;

/**
* @Description: SysRoleService接口
* @author 张瑶
* @date 2018/05/25 23:01
*/
public interface SysRoleService extends Service<SysRole> {

}