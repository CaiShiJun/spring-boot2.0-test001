package com.example.demo.dao.db2;

import com.example.demo.core.universal.Mapper;
import com.example.demo.model.UserLabel;

public interface UserLabelMapper extends Mapper<UserLabel> {
}