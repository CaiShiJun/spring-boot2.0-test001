package com.example.demo.dao.db1;

import com.example.demo.core.universal.Mapper;
import com.example.demo.model.SystemLog;

public interface SystemLogMapper extends Mapper<SystemLog> {
}